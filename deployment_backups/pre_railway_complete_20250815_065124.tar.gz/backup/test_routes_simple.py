#!/usr/bin/env python3

"""
Simple route test - minimal dependencies
"""

try:
    from flask import Flask
    
    # Create minimal Flask app to test routes
    app = Flask(__name__)
    
    # Test the routes we added
    @app.route('/')
    def homepage():
        return "Homepage works!"
    
    @app.route('/lipid-selection')
    @app.route('/dashboard')  # This is the fix we added
    def clean_dashboard():
        return "Dashboard routes work! Both /dashboard and /lipid-selection are accessible."
    
    # Test if we can build URLs
    with app.test_request_context():
        try:
            from flask import url_for
            homepage_url = url_for('homepage')
            dashboard_url = url_for('clean_dashboard')  # This was causing the error
            
            print("✅ Route Test Results:")
            print(f"   Homepage URL: {homepage_url}")
            print(f"   Dashboard URL: {dashboard_url}")
            print("✅ All routes working correctly!")
            print("\nAvailable routes:")
            for rule in app.url_map.iter_rules():
                print(f"   {rule.rule} -> {rule.endpoint}")
                
        except Exception as e:
            print(f"❌ URL building error: {e}")
            
except ImportError as e:
    print(f"❌ Missing Flask: {e}")
    print("Install Flask first: pip install flask")